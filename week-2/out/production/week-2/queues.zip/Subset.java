import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdRandom;

/**
 * Created by theluxury on 9/17/15.
 */
public class Subset {

    public static void main(String[] args) {
        int N = Integer.valueOf(args[0]);

        String[] strings = StdIn.readAllStrings();

        StdRandom.shuffle(strings);

        for (int i = 0; i < N; i++) {
            System.out.println(strings[i]);
        }
    }

}
